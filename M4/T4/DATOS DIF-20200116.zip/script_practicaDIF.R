
# PRACTICA FUNCIONAMIENTO DIFERENCIAL #  QUALEFFO (ESTADO DE ANIMO)  #
# =================================== #  ========================  #

#Directorio de trabajo
setwd("C:/Users/Fujitsu/Desktop/dif_practicaR")

## Instalar y cargar paquete
install.packages("DFIT")
library(DFIT)
install.packages("ltm")
library(ltm)


## Cargar datos (par�metros en la misma escala)

parametros_mh <- read.delim2("C:/Users/Fujitsu/Desktop/1D/parametros_mh.txt", header=FALSE, row.names=NULL)

M<- as.matrix(parametros_mh[1:5])
M
H<- as.matrix(parametros_mh[6:10])
H

datos <- list(focal=M,reference=H)
datos



# Calcula el �ndice CDIF para un item con los par�metros de un item dado de los grupos focal y de referencia.
### Nota: irtModel = grm (Graded Response Model - Polytomous IRT)

Cdif1 <- Cdif(datos, irtModel = 'grm', focalAbilities = NULL, 
              focalDistribution = "norm", subdivisions = 5000, 
              logistic = TRUE)

Cdif1


# Calcula el �ndice DTF para un conjunto de �tems con los par�metros de items dados de los grupos focal y de referencia

Dtf1  <- Dtf(cdif = Cdif1)
Dtf1


# Calcula el �ndice NCDIF para un item con los par�metros de un item dado de los grupos focal y de referencia.

Ncdif1 <- Ncdif(itemParameters = datos, irtModel = 'grm',
                focalAbilities = NULL, focalDistribution = "norm",
                subdivisions = 5000, logistic = TRUE)

Ncdif1

# Plot de curva caracter�stica del elemento (puntaje esperado) para los grupos focales y de referencia para el art�culo, junto con una representaci�n de la densidad del grupo focal.
## Non Uniform - != guess DIF item close to focal distribution
i1<-PlotNcdif(iiItem = 1, itemParameters = datos, irtModel = "grm",
              plotDensity = FALSE, main = "Item 1 Uniform and different guessing DIF")
i1
i2<-PlotNcdif(iiItem = 2, itemParameters = datos, irtModel = "grm",
              plotDensity = FALSE, main = "Item 2 Non Uniform and different guessing DIF")
i2
i3<-PlotNcdif(iiItem = 3, itemParameters = datos, irtModel = "grm",
              plotDensity = FALSE, main = "Item 3 NonUniform and different guessing DIF")
i3
i4<-PlotNcdif(iiItem = 4, itemParameters = datos, irtModel = "grm",
              plotDensity = FALSE, main = "Item 4 Non uniform and different guessing DIF")
i4
i5<-PlotNcdif(iiItem = 5, itemParameters = datos, irtModel = "grm",
              plotDensity = FALSE, main = "Item 5 Uniform and different guessing DIF")
i5
i6<-PlotNcdif(iiItem = 6, itemParameters = datos, irtModel = "grm",
              plotDensity = FALSE, main = "Item 6 Non uniform and different guessing DIF")
i6
i7<-PlotNcdif(iiItem = 7, itemParameters = datos, irtModel = "grm",
              plotDensity = FALSE, main = "Item 7 Uniform and different guessing DIF")
i7
i8<-PlotNcdif(iiItem = 8, itemParameters = datos, irtModel = "grm",
              plotDensity = FALSE, main = "Item 8 Non uniform and different guessing DIF")
i8
i9<-PlotNcdif(iiItem = 9, itemParameters = datos, irtModel = "grm",
              plotDensity = FALSE, main = "Item 9 Non uniform and different guessing DIF")
i9
i10<-PlotNcdif(iiItem = 10, itemParameters = datos, irtModel = "grm",
               plotDensity = FALSE, main = "Item 10 Uniform and different guessing DIF")
i10



