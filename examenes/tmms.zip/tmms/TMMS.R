## ----setup, include = FALSE---------------------------------------------------------------------------------
## knitr::opts_chunk$set(echo = FALSE, warning = FALSE, message = FALSE, eval = F)
## 
## library(haven)
## library(mirt)
## library(psych)
## library(ltm)
## library(magrittr)
## library(knitr)
## library(kableExtra)
## 
## Datos <- read_sav("data/TMMS_corregida2.sav")


## ---- eval=TRUE---------------------------------------------------------------------------------------------
cuest_tmms = data.frame(
  No. = c(1:24),
  Pregunta = c(
    "Presto mucha atención a los sentimientos.",
    "Normalmente me preocupo mucho por lo que siento.",
    "Normalmente dedico tiempo a pensar en mis emociones.",
    "Pienso que merece la pena prestar atención a mis emociones y estado de ánimo.",
    "Dejo que mis sentimientos afecten a mis pensamientos.",
    "Pienso en mi estado de ánimo constantemente.",
    "A menudo pienso en mis sentimientos.",
    "Presto mucha atención a cómo me siento.",
    "Tengo claros mis sentimientos.",
    "Frecuentemente puedo definir mis sentimientos.",
    "Casi siempre sé cómo me siento.",
    "Normalmente conozco mis sentimientos sobre las personas.",
    "A menudo me doy cuenta de mis sentimientos en diferentes situaciones.",
    "Siempre puedo decir cómo me siento.",
    "A veces puedo decir cuáles son mis emociones.",
    "Puedo llegar a comprender mis sentimientos.",
    "Aunque a veces me siento triste, suelo tener una visión optimista.",
    "Aunque me sienta mal, procuro pensar en cosas agradables.",
    "Cuando estoy triste, pienso en todos los placeres de la vida.",
    "Intento tener pensamientos positivos aunque me sienta mal.",
    "Si doy demasiadas vueltas a las cosas, complicándolas, trato de calmarme.",
    "Me preocupo por tener un buen estado de ánimo.",
    "Tengo mucha energía cuando me siento feliz.",
    "Cuando estoy enfadado intento cambiar mi estado de ánimo."
  ),
  n = c(rep(1, times = 24)),
  a = c(rep(2, times = 24)),
  b = c(rep(3, times = 24)),
  m = c(rep(4, times = 24)),
  t = c(rep(5, times = 24))
)

t1 = data.frame("TMMS-24" =  "INSTRUCCIONES: A continuación encontrará algunas afirmaciones sobre sus emociones y sentimientos. Lea atentamente cada frase e indique, por favor, el grado de acuerdo o desacuerdo con respecto a las mismas. **Señale con una “X” la respuesta que más se aproxime a sus preferencias.** \nNo hay respuestas correctas o incorrectas, ni buenas o malas. No emplee mucho tiempo en cada respuesta.")

t2 = data.frame("**1**: Nada de acuerdo", "**2**: Algo de acuerdo", "**3**: Bastante de acuerdo", "**4**: Muy de acuerdo", "**5**: Totalmente de acuerdo.")
t3 = cuest_tmms

k1 = kable(t1, format = "markdown", col.names = "**TMMS-24**")
k2 = kable(t2, format = "markdown", col.names = c(rep("", times = 5)))
k3 = kable(t3, format = "latex", booktabs = F, col.names = c("No.", "Pregunta", "", "", "", "", "")) %>% 
  kable_styling(position = "center") %>% 
  column_spec(1, border_left = T) %>%
  column_spec(7, border_right = T)

k1
k2 
k3



## ---- eval=TRUE---------------------------------------------------------------------------------------------
library(data.table)
library(scales)

previa = foreign::read.spss("data/TMMS_corregida3.sav", to.data.frame = T)

n_prof = as.data.table(table(droplevels(previa$Profesion)))
n_prof[, PROP := N/sum(N)]
n_prof[, V1 := c("curas", "farmacéuticos", "profesores del estado mexicano de Colima", "alumnos universitarios de Portugal", "personas que ni estudian ni trabajan")]
setorder(n_prof, -N)
t_prof = n_prof[, .(V2 = paste0(N = comma(N), " ", V1," (", PROP = percent(PROP), ")"))]

n_sexo = as.data.table(table(droplevels(previa$SEXO)))
n_sexo[, PROP := N/sum(N)]
n_sexo[, V1 := ifelse(V1 == "Hombre", paste0(V1, "s"), paste0(V1, "es"))]
setorder(n_sexo, -N)
t_sexo = n_sexo[, .(V2 = paste0(N = comma(N), " ", tolower(V1)," (", PROP = percent(PROP), ")"))]

n_edad = as.data.table(table(droplevels(previa$EDAD)))
n_edad[, V1 := c("menores de 30", "entre 30 y 40", "de 41 a 50", "mayores a 50")]
n_edad[, PROP := N/sum(N)]
setorder(n_edad, -N)
t_edad = n_edad[, .(V2 = paste0(N = comma(N), " ", V1," (", PROP = percent(PROP), ")"))]

library(likert)
tmms = as.data.table(Datos[, 4:27])
tmmsf = tmms[, lapply(.SD, function(x) factor(x, levels = c("1", "2", "3" , "4", "5"), ordered = T))]
tmmsl = likert(tmmsf)

tab_tmms = as.data.table(tmmsl$results)
tab_tmms[, 2:6] = tab_tmms[, lapply(.SD, round, 1), .SDcols = c(as.character(1:5))]
tab_tmms[, Item := 1:24]
tab_tmms = cbind(Dimensiones = c("Atención", rep("", times = 7), "Claridad", rep("", times = 7), "Reparación", rep("", times = 7)), tab_tmms)

k_tmms = kable(tab_tmms, format = "pandoc", booktabs = T, linesep = c(rep('', times = 7), '\\addlinespace'), caption = "Frecuencias relativas de los reactivos del TMMS-24 por dimensiones\\label{tab:tab_tmms}") %>% 
  kable_styling(position = "center")


## ---- eval=TRUE---------------------------------------------------------------------------------------------
k_tmms


## ---- eval=TRUE---------------------------------------------------------------------------------------------
TMMS <- Datos[,4:27]

# Eliminar valores en 0 || NA
TMMS <- TMMS[!(apply(TMMS, 1, function(y) any(y == 0 | y == 6 | is.na(y)))),]

# Convertir en numeros
TMMS <- mapply(TMMS, FUN = as.numeric)

colnames(TMMS) <- c(paste0("A", 1:8), paste0("C", 9:16), paste0("R", 17:24))

ATENCION <- TMMS[,1:8]
CLARIDAD <- TMMS[,9:16]
REPARACION <- TMMS[,17:24]


## ---- eval=TRUE, out.width='100%', fig.cap="Modelo confirmatorio del TMMS-24"-------------------------------
knitr::include_graphics('./mapa_AMOS.jpeg')


## ---- eval=TRUE---------------------------------------------------------------------------------------------
PolyTMMS <- polychoric(TMMS)

irtTMMS <- irt.fa(PolyTMMS, plot = FALSE)

par(mfrow = c(1,2))
plot(irtTMMS, main = "Información del ítem", xlab = "Caract. latente (escala normal)", ylab = "Información del ítem")
plot(irtTMMS, type = "test", main = "Información del test", xlab = "Caract. latente (escala normal)", ylab = "Información del test")


## -----------------------------------------------------------------------------------------------------------
## PolyATENCION <- polychoric(ATENCION)
## irtATENCION <- irt.fa(PolyATENCION)


## -----------------------------------------------------------------------------------------------------------
## irtATENCION$tau


## -----------------------------------------------------------------------------------------------------------
## mirtATENCION <- mirt(ATENCION, model = 1, technical = list(removeEmptyRows=TRUE))
## summary(mirtATENCION)
## mirtATENCION


## -----------------------------------------------------------------------------------------------------------
## plot(mirtATENCION, type = "info")


## -----------------------------------------------------------------------------------------------------------
## plot(mirtATENCION, type = "infotrace")


## -----------------------------------------------------------------------------------------------------------
## PolyCLARIDAD <- polychoric(CLARIDAD)
## irtCLARIDAD <- irt.fa(PolyCLARIDAD)


## -----------------------------------------------------------------------------------------------------------
## irtCLARIDAD$tau


## -----------------------------------------------------------------------------------------------------------
## mirtCLARIDAD <- mirt(CLARIDAD, model = 1, technical = list(removeEmptyRows=TRUE))
## summary(mirtCLARIDAD)
## mirtCLARIDAD


## -----------------------------------------------------------------------------------------------------------
## plot(mirtCLARIDAD, type = "info")


## -----------------------------------------------------------------------------------------------------------
## plot(mirtCLARIDAD, type = "infotrace")


## -----------------------------------------------------------------------------------------------------------
## PolyREPARACION <- polychoric(REPARACION)
## irtREPARACION <- irt.fa(PolyREPARACION)


## -----------------------------------------------------------------------------------------------------------
## irtREPARACION$tau


## -----------------------------------------------------------------------------------------------------------
## mirtREPARACION <- mirt(REPARACION, model = 1, technical = list(removeEmptyRows=TRUE))
## summary(mirtREPARACION)
## mirtREPARACION


## -----------------------------------------------------------------------------------------------------------
## plot(mirtREPARACION, type = "info")


## -----------------------------------------------------------------------------------------------------------
## plot(mirtREPARACION, type = "infotrace")


## -----------------------------------------------------------------------------------------------------------
## irtATENCION$irt$discrimination


## -----------------------------------------------------------------------------------------------------------
## irtCLARIDAD$irt$discrimination


## -----------------------------------------------------------------------------------------------------------
## irtREPARACION$irt$discrimination


## -----------------------------------------------------------------------------------------------------------
## plot(mirtATENCION, type = "trace")


## -----------------------------------------------------------------------------------------------------------
## plot(mirtCLARIDAD, type = "trace")


## -----------------------------------------------------------------------------------------------------------
## plot(mirtREPARACION, type = "trace")


## -----------------------------------------------------------------------------------------------------------
## # Frequencia
## TMMSfeq <- ifelse(TMMS > 1, 1, 0)
## feq <- colSums(TMMSfeq) / dim(TMMS)[1] * 100
## 
## # Importancia
## TMMSmea <- TMMS[!(apply(TMMS, 1, function(y) any(y == 1))),]
## mea <- colMeans(TMMSmea)
## 
## # Impacto
## TMMSimpa <- cbind(feq, mea, feq * mea)
## colnames(TMMSimpa) = c("Frecuencia","Importancia","Impacto")
## TMMSimpa


## -----------------------------------------------------------------------------------------------------------
## cronbach.alpha(TMMS, na.rm = TRUE)


## -----------------------------------------------------------------------------------------------------------
## library(stargazer)


## -----------------------------------------------------------------------------------------------------------
## cronbach.alpha(ATENCION, na.rm = TRUE)


## -----------------------------------------------------------------------------------------------------------
## cronbach.alpha(CLARIDAD, na.rm = TRUE)


## -----------------------------------------------------------------------------------------------------------
## cronbach.alpha(REPARACION, na.rm = TRUE)

